# REIMS - đồ án quản lý bất động sản và cho thuê

Bộ mã này chuyển thiết kế trong báo cáo thành cơ sở dữ liệu MySQL 8.0.16+. Lược đồ giữ nguyên 10 bảng lõi và bổ sung 3 bảng: `rental_invoice`, `sale_transaction` và `property_status_history`; phần lịch xem nhà được lược khỏi phạm vi theo quyết định của nhóm. Khoản phải thu được tách khỏi tiền thực nhận. Dữ liệu demo được sinh bằng stored procedure, hoàn toàn giả lập; tổng số dòng vượt 4.000.

## Nội dung thư mục

- `01_schema.sql`: tạo cơ sở dữ liệu, 13 bảng, khóa/ràng buộc, chỉ mục, 6 trigger, 1 procedure sinh hóa đơn tháng và 2 view.
- `02_seed_1000_plus.sql`: nạp 1.200 người với tên tiếng Việt giả lập (ví dụ Nguyen Van An), 300 bất động sản, hợp đồng thuê, hóa đơn, thanh toán, yêu cầu bảo trì và giao dịch bán.
- `03_queries.sql`: 14 truy vấn minh họa join, subquery, CTE, aggregate, báo cáo nợ, hiệu suất môi giới và dòng tiền.
- `04_update_person_names.sql`: đổi tên placeholder trong dữ liệu đã nạp mà không tạo lại bảng hay thay đổi khóa ngoại.
- `ui/`: giao diện web Flask kết nối MySQL để quản lý tài sản, hợp đồng thuê, thanh toán và bảo trì. Cách cài đặt nằm trong `ui/README_UI_VI.md`.

## Chạy bằng MySQL

1. Cài MySQL Server 8.0.16 trở lên và MySQL Workbench, hoặc dùng terminal.
2. Mở MySQL Workbench và kết nối tới server local. Chạy toàn bộ `01_schema.sql` trước.
3. Chạy toàn bộ `02_seed_1000_plus.sql`. Cuối file có truy vấn đếm dòng theo bảng.
   Nếu đã có dữ liệu demo với tên dạng `Customer 001`, chạy `04_update_person_names.sql`; không cần chạy lại schema hoặc seed.
4. Chạy từng câu trong `03_queries.sql` để trình bày yêu cầu truy vấn phức tạp.
5. Mở `v_property_dashboard` và `v_overdue_invoices`; trình bày trigger bằng giao dịch thử trên bản sao dữ liệu hoặc dùng property/lease demo phù hợp.
6. Để chạy giao diện web, làm theo `ui/README_UI_VI.md`. Workbench dùng để chạy SQL và kiểm tra dữ liệu; Flask cung cấp UI trình duyệt.

Có thể chạy terminal trên Linux/macOS/Windows nếu lệnh `mysql` nằm trong PATH:

```bash
mysql -u root -p < 01_schema.sql
mysql -u root -p < 02_seed_1000_plus.sql
mysql -u root -p reims_db < 04_update_person_names.sql
mysql -u root -p reims_db < 03_queries.sql
```

`01_schema.sql` xóa và tạo lại các bảng của `reims_db` khi chạy lại. Hãy sao lưu dữ liệu đang cần giữ trước khi chạy lại file này.

## Trigger, view và procedure

- `trg_lease_status_guard` ngăn kích hoạt lease nếu tài sản không còn AVAILABLE/FOR_RENT.
- `trg_lease_status_sync` cập nhật trạng thái bất động sản khi lease bắt đầu/kết thúc.
- `trg_maintenance_status_sync` đồng bộ trạng thái tài sản khi yêu cầu bảo trì được xử lý.
- `trg_sale_status_guard` và `trg_sale_status_sync` kiểm soát chốt giao dịch bán và chuyển tài sản sang SOLD.
- `trg_property_status_history` ghi lịch sử khi trạng thái property thay đổi.
- `v_property_dashboard` tổng hợp danh mục hiện tại; `v_overdue_invoices` liệt kê hóa đơn quá hạn và số dư.
- `sp_generate_monthly_invoices('2026-11-01')` tạo hóa đơn cho các lease ACTIVE trọn tháng 11/2026. Procedure có thể gọi lại an toàn vì mỗi lease chỉ có một hóa đơn cho từng kỳ. Tháng bắt đầu/kết thúc giữa kỳ cần quy tắc tính tiền prorate riêng trước khi áp dụng thực tế.

Ví dụ kích hoạt hợp đồng thuê bằng cập nhật trạng thái (chỉ dùng bản demo phù hợp):

```sql
UPDATE lease SET status='ACTIVE' WHERE lease_id=...;
```

Hủy/kết thúc hợp đồng:

```sql
UPDATE lease SET status='TERMINATED' WHERE lease_id=...;
```

Chốt giao dịch bán: tạo `sale_transaction` với trạng thái `APPROVED`, sau đó cập nhật thành `CLOSED`; trigger sẽ chuyển tài sản sang `SOLD`.

## Nhận xét thiết kế và điểm cần sửa trong báo cáo

### Phần làm tốt

- Dùng `PERSON` và các bảng subtype `OWNER`, `TENANT`, `AGENT` là cách ánh xạ ISA rõ ràng; subtype dùng PK đồng thời làm FK.
- Đưa thuộc tính nhà ở và thương mại vào hai bảng subtype giúp tránh nhiều cột NULL.
- Các bảng lõi có khóa chính đơn, FK thể hiện đúng các quan hệ 1:N; thiết kế hợp lý để chứng minh 1NF/2NF/3NF/BCNF theo các phụ thuộc hàm đã nêu.
- Số điện thoại và CCCD dùng kiểu chuỗi; tiền dùng DECIMAL; lịch sử thanh toán không bị xóa theo cascade.

### Các điểm nên chỉnh trước khi nộp

1. **Thống nhất phạm vi xem nhà.** Báo cáo hiện có yêu cầu đặt lịch xem; vì nhóm bỏ nghiệp vụ này, hãy xóa yêu cầu tương ứng khỏi problem statement, functional requirements, business rules, ERD và data dictionary, hoặc ghi rõ đây là phần ngoài phạm vi.
2. **Tách hóa đơn khỏi thanh toán.** `PAYMENT` trong báo cáo vừa được mô tả là khoản thuê/đặt cọc, vừa phải có trạng thái thanh toán và sinh định kỳ. Nếu không có `INVOICE`, khó phân biệt khoản phải trả, thanh toán một phần, quá hạn và tiền đã nhận. Bộ SQL dùng `RENTAL_INVOICE` cho khoản phải thu và `PAYMENT` cho dòng tiền thực nhận.
3. **Thêm giao dịch bán.** `FOR_SALE` chỉ ghi mục đích và giá chào, chưa ghi người mua, giá chốt, ngày ký/hoàn tất hoặc hoa hồng. Bộ SQL thêm `SALE_TRANSACTION`.
4. **Bổ sung trạng thái SOLD.** Ba trạng thái hiện tại không thể mô tả tài sản đã bán. Bộ SQL bổ sung `SOLD`; nên cập nhật BR-03 và EER/data dictionary tương ứng. Nếu giảng viên yêu cầu giữ đúng 3 trạng thái, cần giải thích cách biểu diễn tài sản bán bên ngoài `PROPERTY.Status`.
5. **Sửa ràng buộc agent của PROPERTY.** BR-06 nói một property có thể được phân cho *at most one* agent, tức AgentID có thể NULL. Data dictionary lại đánh dấu AgentID NOT NULL và quan hệ định nghĩa thành đúng một agent. Chọn một cách, đồng bộ EER, nullable và business rule. Bản SQL hiện chọn agent bắt buộc vì phù hợp actor/triển khai demo.
6. **Ghi rõ quy tắc ISA.** Nêu PERSON subtype là partial hay total và disjoint hay overlapping; tương tự PROPERTY subtype. Ví dụ, một người có thể vừa là owner vừa là tenant không? Một property có bắt buộc đúng một subtype không? Nếu có, cần kiểm tra ở ứng dụng/transaction hoặc trigger phù hợp.
7. **Thêm lịch sử phân công agent/listing nếu cần audit.** Lưu AgentID hiện tại trực tiếp trên PROPERTY đủ cho trạng thái hiện hành nhưng mất lịch sử ai phụ trách/đăng giá vào thời điểm nào. Có thể bổ sung `PROPERTY_ASSIGNMENT_HISTORY` hoặc bảng `LISTING` nếu đề tài cần nhiều đợt đăng.
8. **Chuẩn hóa giải thích tiền và hoa hồng.** Báo cáo cần định nghĩa rõ Price là giá bán hay tiền thuê theo tháng, commission tính trên giá chốt hay tiền thuê, ai là người trả phí. Bộ SQL giữ `asking_price`, `monthly_rent`, `sale_price` và snapshot `commission_rate_at_sale` riêng.
9. **Sửa tham chiếu Business Rule.** Trong phần mô tả entity/table, một số BR được dẫn không đúng chủ đề (ví dụ IDCardNumber gắn BR về lease, mô tả PAYMENT/Maintenance dẫn số BR lệch). Rà toàn bộ numbering và bảo đảm cùng một định nghĩa giữa business rules, ERD, relational schema và data dictionary.
10. **Đối chiếu yêu cầu với schema.** Sau khi bỏ lịch xem, rà lại toàn báo cáo để không còn bảng/quan hệ hay truy vấn nào ngầm yêu cầu chức năng đó; giữ nhất quán giữa scope, business rules, ERD và data dictionary.

Các trigger trong bộ demo xử lý các chuyển đổi phổ biến. Với ứng dụng thực tế, nên giới hạn quyền cập nhật trạng thái trực tiếp và chỉ cho phép thao tác qua stored procedure/transaction để tránh người dùng ghi đè trạng thái không đúng nghiệp vụ.

## Các bước hoàn thiện đồ án theo rubric

1. **Chốt conceptual design:** thống nhất các quy tắc ISA, `AgentID` có bắt buộc không, lịch sử listing, trạng thái SOLD và nghiệp vụ mua bán; cập nhật ER/EER và business rules.
2. **Chốt logical design:** cập nhật quan hệ, PK/FK/alternate key, cardinality, nullability, domain, `ON DELETE` policy. Giải thích functional dependencies và 3NF/BCNF cho từng relation; nêu giả định nghiệp vụ.
3. **Implementation:** chạy DDL, dữ liệu giả lập, chụp kết quả đếm bản ghi, thực thi ít nhất 10 truy vấn. Giải thích mỗi index và constraint hỗ trợ truy vấn/rule nào.
4. **Kiểm tra integrity:** chuẩn bị demo hợp lệ và trường hợp bị từ chối (active lease trùng property, kích hoạt lease ở property đang bảo trì, amount <= 0, end date trước start date). Nêu expected behavior.
5. **UI/backend:** chạy Flask trong thư mục `ui`; demo tìm/tạo property, tạo lease, ghi invoice/payment, xử lý maintenance và xem overdue. Ứng dụng dùng parameterized queries và transaction; bổ sung đăng nhập/phân quyền nếu nhóm muốn mở rộng phạm vi.
6. **Chuẩn bị bảo vệ nhóm 3 người:** chia phần ERD/normalization, DDL/constraints, query/triggers/UI; mỗi thành viên luyện giải thích và tự viết một truy vấn khi bị hỏi vì điểm SQL defense tính cá nhân.
7. **Demo presentation:** đi theo luồng tìm tài sản → đặt xem → ký lease → sinh hóa đơn → nhận payment → ghi maintenance → kết thúc lease; cuối cùng trình bày dashboard, lịch sử tài chính và trade-off thiết kế.

### Lưu ý về bộ dữ liệu

Tên, email, điện thoại, địa chỉ và giao dịch trong seed là dữ liệu minh họa tổng hợp, không phải thông tin khách hàng có thật. Bộ dữ liệu đủ lớn để trình bày truy vấn và chỉ mục ở quy mô đồ án; không đại diện cho benchmark hiệu năng production.
