# REIMS — Real Estate Property & Rental Ledger

Bộ đồ án triển khai bằng MySQL 8 và Flask. Database có **10 bảng nghiệp vụ** cùng một bảng tài khoản phục vụ đăng nhập/phân quyền. Hệ thống quản lý người, chủ sở hữu, agent, khách thuê, bất động sản nhà ở/thương mại, hợp đồng thuê, lịch sử thanh toán và yêu cầu bảo trì. Bất động sản có thể được đăng bán hoặc cho thuê.

Dữ liệu seed là dữ liệu giả lập, có 4.000 dòng để minh họa truy vấn. Mỗi hợp đồng ACTIVE có một khoản thu demo mang ngày hiện tại để thẻ “thu trong tháng” và truy vấn dòng tiền có dữ liệu ngay sau khi nạp seed. Dòng `payment` lưu khoản thu/hoàn tiền trực tiếp gắn với hợp đồng thuê.

## Actor và quyền truy cập

- **ADMIN / Property Manager:** xem và quản lý toàn bộ tài sản, phân công agent, xem sổ thu chi, duyệt/từ chối lease đang chờ, kết thúc lease và cập nhật yêu cầu bảo trì.
- **AGENT:** chỉ xem và sửa tin đăng của tài sản được giao; tạo lease chờ duyệt cho tài sản được giao; tạo yêu cầu bảo trì cho lease do mình phụ trách.
- **OWNER:** chỉ xem tài sản, lease, payment và bảo trì gắn với tài sản mình sở hữu.
- **TENANT / BUYER:** chỉ xem tin đang AVAILABLE; xem lease/payment/bảo trì của hồ sơ cá nhân; tạo yêu cầu lease, ghi payment và gửi yêu cầu bảo trì cho lease của mình.

Quyền được kiểm tra trên server cho mỗi request; ẩn nút trên giao diện chỉ hỗ trợ trải nghiệm và không thay thế kiểm tra quyền. Mỗi tài khoản gắn với đúng một loại hồ sơ. Tenant/Buyer được phép gắn với hồ sơ Tenant hoặc hồ sơ Buyer chưa thuộc Owner/Agent.

Khi database chưa có Admin, trang khởi động một lần cho phép tạo tài khoản Admin đầu tiên. Sau khi đăng nhập, Admin tạo tài khoản actor khác ở mục **Accounts**. Mật khẩu được lưu dưới dạng hash; tài khoản có thể bị vô hiệu hóa.

## Phạm vi hiện tại và hướng phát triển

Phiên bản hiện tại tập trung vào danh sách bất động sản bán/cho thuê, phân quyền theo actor, lease và ghi nhận payment, cùng yêu cầu bảo trì. Các chức năng sau **chưa được triển khai** và được xác định là hướng phát triển tiếp theo:

- Lịch đặt xem nhà cho Agent và Tenant/Buyer.
- Nhắc sắp hết hạn, hợp đồng hết hạn và khoản thanh toán quá hạn.
- Hóa đơn thuê định kỳ, số dư phải thu và theo dõi công nợ.
- Quy trình hoàn tất giao dịch bán, lưu lịch sử giao dịch và tính hoa hồng.
- Lưu lịch sử thay đổi trạng thái bất động sản.

Lease tạo bởi Admin, Agent hoặc Tenant/Buyer bắt đầu ở trạng thái PENDING; chỉ Admin mới được duyệt/từ chối. Tài khoản và kết quả duyệt lease đã được lưu trong database. Payment hiện tại chỉ là nhật ký khoản thu/hoàn tiền đã ghi nhận; hệ thống chưa tính công nợ hay lập hóa đơn. Bất động sản đăng bán được quản lý dưới dạng tin đăng, chưa có quy trình chốt giao dịch bán.

## Cấu trúc

- `01_schema.sql`: tạo database, 10 bảng nghiệp vụ, bảng `user_account`, view tổng quan, trigger trạng thái và kiểm tra vai trò.
- `02_seed_1000_plus.sql`: thêm dữ liệu demo.
- `03_queries.sql`: 14 truy vấn minh họa lọc, join, tổng hợp, CTE và hàm ngày.
- `04_update_person_names.sql`: cập nhật tên người trong dữ liệu demo hiện có.
- `05_auth_migration.sql`: bổ sung tài khoản và thông tin duyệt lease mà không xóa dữ liệu hiện có.
- `ui/`: giao diện Flask để xem tài sản, tạo lease, ghi payment và xử lý bảo trì.

## Chạy database

Trong MySQL Workbench, kết nối tới MySQL Server và chạy lần lượt:

1. `01_schema.sql`
2. `02_seed_1000_plus.sql`
3. `03_queries.sql` khi cần xem các truy vấn minh họa.

`01_schema.sql` xóa và tạo lại các bảng dự án, nên nếu đã có dữ liệu cần giữ thì sao lưu trước khi chạy lại.

Nếu đã có database và muốn giữ dữ liệu, chỉ chạy `05_auth_migration.sql` thay cho việc chạy lại `01_schema.sql`; sau đó khởi động lại web và tạo tài khoản Admin đầu tiên.

## Quy tắc trạng thái

- Chỉ tài sản `AVAILABLE` và `FOR_RENT` mới kích hoạt được lease.
- Mỗi tài sản có tối đa một lease `ACTIVE`.
- Kích hoạt lease đồng bộ property thành `LEASED`; kết thúc lease đưa property về `AVAILABLE`, trừ khi còn yêu cầu bảo trì đang `IN_PROGRESS`.
- Bắt đầu sửa chữa chuyển property sang `UNDER_MAINTENANCE`. Hoàn tất/hủy yêu cầu chỉ phục hồi trạng thái khi không còn yêu cầu nào khác đang xử lý; trạng thái tiếp theo dựa trên lease `ACTIVE`.
- Payment được lưu riêng theo lease và không bị xóa khi lease kết thúc.

## Chạy giao diện

Dùng launcher trong thư mục `ui`: `run_ui.sh` cho Linux/macOS hoặc `run_ui.bat` cho Windows. MySQL Server phải đang chạy và database cần được tạo/nạp seed trước.
