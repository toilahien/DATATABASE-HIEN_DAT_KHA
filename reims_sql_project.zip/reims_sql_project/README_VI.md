# REIMS — Real Estate Property & Rental Ledger

Bộ đồ án triển khai bằng MySQL 8 và Flask, giữ phạm vi gọn với **10 bảng**. Hệ thống quản lý người, chủ sở hữu, agent, khách thuê, bất động sản nhà ở/thương mại, hợp đồng thuê, lịch sử thanh toán và yêu cầu bảo trì. Bất động sản có thể được đăng bán hoặc cho thuê.

Dữ liệu seed là dữ liệu giả lập, có 4.000 dòng để minh họa truy vấn. Mỗi hợp đồng ACTIVE có một khoản thu demo mang ngày hiện tại để thẻ “thu trong tháng” và truy vấn dòng tiền có dữ liệu ngay sau khi nạp seed. Dòng `payment` lưu khoản thu/hoàn tiền trực tiếp gắn với hợp đồng thuê. Thiết kế này không quản lý hóa đơn định kỳ, số dư phải thu, giao dịch bán đã chốt hoặc lịch sử thay đổi trạng thái tài sản.

## Cấu trúc

- `01_schema.sql`: tạo database, 10 bảng, view tổng quan và trigger đồng bộ trạng thái.
- `02_seed_1000_plus.sql`: thêm dữ liệu demo.
- `03_queries.sql`: 14 truy vấn minh họa lọc, join, tổng hợp, CTE và hàm ngày.
- `04_update_person_names.sql`: cập nhật tên người trong dữ liệu demo hiện có.
- `ui/`: giao diện Flask để xem tài sản, tạo lease, ghi payment và xử lý bảo trì.

## Chạy database

Trong MySQL Workbench, kết nối tới MySQL Server và chạy lần lượt:

1. `01_schema.sql`
2. `02_seed_1000_plus.sql`
3. `03_queries.sql` khi cần xem các truy vấn minh họa.

`01_schema.sql` xóa và tạo lại các bảng dự án, nên nếu đã có dữ liệu cần giữ thì sao lưu trước khi chạy lại.

## Quy tắc trạng thái

- Chỉ tài sản `AVAILABLE` và `FOR_RENT` mới kích hoạt được lease.
- Mỗi tài sản có tối đa một lease `ACTIVE`.
- Kích hoạt lease đồng bộ property thành `LEASED`; kết thúc lease đưa property về `AVAILABLE`, trừ khi còn yêu cầu bảo trì đang `IN_PROGRESS`.
- Bắt đầu sửa chữa chuyển property sang `UNDER_MAINTENANCE`. Hoàn tất/hủy yêu cầu chỉ phục hồi trạng thái khi không còn yêu cầu nào khác đang xử lý; trạng thái tiếp theo dựa trên lease `ACTIVE`.
- Payment được lưu riêng theo lease và không bị xóa khi lease kết thúc.

## Chạy giao diện

Dùng launcher trong thư mục `ui`: `run_ui.sh` cho Linux/macOS hoặc `run_ui.bat` cho Windows. MySQL Server phải đang chạy và database cần được tạo/nạp seed trước.
