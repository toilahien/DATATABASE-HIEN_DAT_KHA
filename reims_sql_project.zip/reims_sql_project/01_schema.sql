lease-- REIMS - MySQL 8.0.16+
-- Run this file first. Re-running drops and recreates the project database.
CREATE DATABASE IF NOT EXISTS reims_db CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE reims_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW IF EXISTS v_overdue_invoices;
DROP VIEW IF EXISTS v_property_dashboard;
DROP TABLE IF EXISTS property_status_history;
DROP TABLE IF EXISTS sale_transaction;
DROP TABLE IF EXISTS maintenance_request;
DROP TABLE IF EXISTS payment;
DROP TABLE IF EXISTS rental_invoice;
DROP TABLE IF EXISTS lease;
DROP TABLE IF EXISTS commercial_property;
DROP TABLE IF EXISTS residential_property;
DROP TABLE IF EXISTS property;
DROP TABLE IF EXISTS tenant;
DROP TABLE IF EXISTS agent;
DROP TABLE IF EXISTS owner;
DROP TABLE IF EXISTS person;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE person (
    person_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(150) UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE owner (
    person_id BIGINT UNSIGNED PRIMARY KEY,
    mailing_address VARCHAR(255) NOT NULL,
    CONSTRAINT fk_owner_person FOREIGN KEY (person_id) REFERENCES person(person_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tenant (
    person_id BIGINT UNSIGNED PRIMARY KEY,
    id_card_number VARCHAR(30) NOT NULL UNIQUE,
    CONSTRAINT fk_tenant_person FOREIGN KEY (person_id) REFERENCES person(person_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE agent (
    person_id BIGINT UNSIGNED PRIMARY KEY,
    commission_rate DECIMAL(5,2) NOT NULL,
    CONSTRAINT chk_agent_commission CHECK (commission_rate >= 0 AND commission_rate <= 100),
    CONSTRAINT fk_agent_person FOREIGN KEY (person_id) REFERENCES person(person_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE property (
    property_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    address VARCHAR(255) NOT NULL,
    property_type ENUM('RESIDENTIAL','COMMERCIAL') NOT NULL,
    listing_type ENUM('FOR_SALE','FOR_RENT') NOT NULL,
    asking_price DECIMAL(15,2) NOT NULL,
    status ENUM('AVAILABLE','LEASED','UNDER_MAINTENANCE','SOLD') NOT NULL DEFAULT 'AVAILABLE',
    owner_id BIGINT UNSIGNED NOT NULL,
    agent_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_property_price CHECK (asking_price > 0),
    CONSTRAINT chk_sold_is_sale CHECK (status <> 'SOLD' OR listing_type = 'FOR_SALE'),
    CONSTRAINT fk_property_owner FOREIGN KEY (owner_id) REFERENCES owner(person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_property_agent FOREIGN KEY (agent_id) REFERENCES agent(person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_property_search (listing_type, status, asking_price),
    INDEX ix_property_owner (owner_id),
    INDEX ix_property_agent (agent_id)
) ENGINE=InnoDB;

CREATE TABLE residential_property (
    property_id BIGINT UNSIGNED PRIMARY KEY,
    bedrooms TINYINT UNSIGNED NOT NULL,
    bathrooms TINYINT UNSIGNED NOT NULL,
    area_sqm DECIMAL(10,2) NOT NULL,
    furnished_status ENUM('FURNISHED','PARTLY_FURNISHED','UNFURNISHED') NULL,
    CONSTRAINT chk_residential_area CHECK (area_sqm > 0),
    CONSTRAINT fk_residential_property FOREIGN KEY (property_id) REFERENCES property(property_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE commercial_property (
    property_id BIGINT UNSIGNED PRIMARY KEY,
    business_type VARCHAR(60),
    floor_area_sqm DECIMAL(10,2) NOT NULL,
    parking_spaces SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    CONSTRAINT chk_commercial_area CHECK (floor_area_sqm > 0),
    CONSTRAINT fk_commercial_property FOREIGN KEY (property_id) REFERENCES property(property_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE lease (
    lease_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    monthly_rent DECIMAL(15,2) NOT NULL,
    deposit_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    payment_day TINYINT UNSIGNED NOT NULL DEFAULT 1,
    status ENUM('PENDING','ACTIVE','EXPIRED','TERMINATED','REJECTED') NOT NULL DEFAULT 'PENDING',
    property_id BIGINT UNSIGNED NOT NULL,
    tenant_id BIGINT UNSIGNED NOT NULL,
    agent_id BIGINT UNSIGNED NOT NULL,
    active_property_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN status = 'ACTIVE' THEN property_id ELSE NULL END) STORED,
    CONSTRAINT chk_lease_dates CHECK (end_date > start_date),
    CONSTRAINT chk_lease_rent CHECK (monthly_rent > 0),
    CONSTRAINT chk_lease_deposit CHECK (deposit_amount >= 0),
    CONSTRAINT chk_payment_day CHECK (payment_day BETWEEN 1 AND 28),
    CONSTRAINT uq_one_active_lease_per_property UNIQUE (active_property_id),
    CONSTRAINT fk_lease_property FOREIGN KEY (property_id) REFERENCES property(property_id) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_lease_tenant FOREIGN KEY (tenant_id) REFERENCES tenant(person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_lease_agent FOREIGN KEY (agent_id) REFERENCES agent(person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_lease_dates_status (status, start_date, end_date),
    INDEX ix_lease_tenant (tenant_id)
) ENGINE=InnoDB;

-- Invoice = amount due; payment = money actually received. Keeping them separate makes arrears measurable.
CREATE TABLE rental_invoice (
    invoice_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lease_id BIGINT UNSIGNED NOT NULL,
    billing_period_start DATE NOT NULL,
    billing_period_end DATE NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    amount_due DECIMAL(15,2) NOT NULL,
    status ENUM('UNPAID','PARTIALLY_PAID','PAID','VOID') NOT NULL DEFAULT 'UNPAID',
    CONSTRAINT chk_invoice_period CHECK (billing_period_end >= billing_period_start),
    CONSTRAINT chk_invoice_amount CHECK (amount_due > 0),
    CONSTRAINT uq_invoice_period UNIQUE (lease_id, billing_period_start),
    CONSTRAINT fk_invoice_lease FOREIGN KEY (lease_id) REFERENCES lease(lease_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_invoice_due (status, due_date)
) ENGINE=InnoDB;

CREATE TABLE payment (
    payment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lease_id BIGINT UNSIGNED NOT NULL,
    invoice_id BIGINT UNSIGNED NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    payment_type ENUM('RENT','DEPOSIT','FEE','REFUND') NOT NULL DEFAULT 'RENT',
    payment_method ENUM('CASH','BANK_TRANSFER','CARD','E_WALLET','OTHER') NULL,
    reference_code VARCHAR(80) NULL UNIQUE,
    status ENUM('POSTED','REVERSED') NOT NULL DEFAULT 'POSTED',
    notes VARCHAR(255),
    CONSTRAINT chk_payment_amount CHECK (amount > 0),
    CONSTRAINT fk_payment_lease FOREIGN KEY (lease_id) REFERENCES lease(lease_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_payment_invoice FOREIGN KEY (invoice_id) REFERENCES rental_invoice(invoice_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_payment_date (payment_date),
    INDEX ix_payment_lease (lease_id)
) ENGINE=InnoDB;

CREATE TABLE maintenance_request (
    request_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lease_id BIGINT UNSIGNED NOT NULL,
    description TEXT NOT NULL,
    report_date DATE NOT NULL,
    estimated_cost DECIMAL(15,2) NULL,
    actual_cost DECIMAL(15,2) NULL,
    status ENUM('PENDING','IN_PROGRESS','COMPLETED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    resolved_at DATETIME NULL,
    CONSTRAINT chk_maintenance_estimate CHECK (estimated_cost IS NULL OR estimated_cost >= 0),
    CONSTRAINT chk_maintenance_actual CHECK (actual_cost IS NULL OR actual_cost >= 0),
    CONSTRAINT fk_maintenance_lease FOREIGN KEY (lease_id) REFERENCES lease(lease_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_maintenance_status (status, report_date)
) ENGINE=InnoDB;

CREATE TABLE sale_transaction (
    sale_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    property_id BIGINT UNSIGNED NOT NULL UNIQUE,
    buyer_id BIGINT UNSIGNED NOT NULL,
    agent_id BIGINT UNSIGNED NOT NULL,
    sale_price DECIMAL(15,2) NOT NULL,
    commission_rate_at_sale DECIMAL(5,2) NOT NULL,
    contract_date DATE NOT NULL,
    closing_date DATE NULL,
    status ENUM('OFFERED','APPROVED','CLOSED','CANCELLED') NOT NULL DEFAULT 'OFFERED',
    CONSTRAINT chk_sale_price CHECK (sale_price > 0),
    CONSTRAINT chk_sale_commission CHECK (commission_rate_at_sale BETWEEN 0 AND 100),
    CONSTRAINT fk_sale_property FOREIGN KEY (property_id) REFERENCES property(property_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_sale_buyer FOREIGN KEY (buyer_id) REFERENCES tenant(person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_sale_agent FOREIGN KEY (agent_id) REFERENCES agent(person_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_sale_status (status, contract_date)
) ENGINE=InnoDB;

CREATE TABLE property_status_history (
    history_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    property_id BIGINT UNSIGNED NOT NULL,
    old_status ENUM('AVAILABLE','LEASED','UNDER_MAINTENANCE','SOLD') NULL,
    new_status ENUM('AVAILABLE','LEASED','UNDER_MAINTENANCE','SOLD') NOT NULL,
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reason VARCHAR(120) NOT NULL DEFAULT 'Manual update',
    CONSTRAINT fk_status_history_property FOREIGN KEY (property_id) REFERENCES property(property_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX ix_status_history_property (property_id, changed_at)
) ENGINE=InnoDB;

DELIMITER $$
CREATE TRIGGER trg_property_status_history
AFTER UPDATE ON property
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO property_status_history(property_id, old_status, new_status, reason)
        VALUES (NEW.property_id, OLD.status, NEW.status, 'Property status updated');
    END IF;
END$$

CREATE TRIGGER trg_lease_status_guard
BEFORE UPDATE ON lease
FOR EACH ROW
BEGIN
    DECLARE v_status VARCHAR(30);
    DECLARE v_listing VARCHAR(20);
    IF NEW.status = 'ACTIVE' AND (OLD.status <> 'ACTIVE' OR NEW.property_id <> OLD.property_id) THEN
        SELECT status, listing_type INTO v_status, v_listing
        FROM property WHERE property_id = NEW.property_id FOR UPDATE;
        IF v_status <> 'AVAILABLE' OR v_listing <> 'FOR_RENT' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Lease activation requires an available FOR_RENT property';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_lease_status_sync
AFTER UPDATE ON lease
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        IF NEW.status = 'ACTIVE' AND (OLD.status <> 'ACTIVE' OR NEW.property_id <> OLD.property_id) THEN
            IF OLD.status = 'ACTIVE' AND OLD.property_id <> NEW.property_id THEN
                UPDATE property SET status = 'AVAILABLE' WHERE property_id = OLD.property_id AND status = 'LEASED';
            END IF;
            UPDATE property SET status = 'LEASED' WHERE property_id = NEW.property_id;
        ELSEIF OLD.status = 'ACTIVE' AND NEW.status IN ('EXPIRED','TERMINATED') THEN
            UPDATE property SET status = 'AVAILABLE'
            WHERE property_id = NEW.property_id AND status = 'LEASED';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_maintenance_status_sync
AFTER UPDATE ON maintenance_request
FOR EACH ROW
BEGIN
    DECLARE v_property_id BIGINT UNSIGNED;
    DECLARE v_lease_status VARCHAR(20);
    IF OLD.status <> NEW.status THEN
        SELECT property_id, status INTO v_property_id, v_lease_status FROM lease WHERE lease_id = NEW.lease_id;
        IF NEW.status = 'IN_PROGRESS' THEN
            UPDATE property SET status = 'UNDER_MAINTENANCE' WHERE property_id = v_property_id AND status IN ('AVAILABLE','LEASED');
        ELSEIF NEW.status = 'COMPLETED' AND OLD.status = 'IN_PROGRESS' THEN
            UPDATE property SET status = IF(v_lease_status = 'ACTIVE','LEASED','AVAILABLE')
            WHERE property_id = v_property_id AND status = 'UNDER_MAINTENANCE';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_sale_status_guard
BEFORE UPDATE ON sale_transaction
FOR EACH ROW
BEGIN
    DECLARE v_status VARCHAR(30);
    DECLARE v_listing VARCHAR(20);
    IF NEW.status = 'CLOSED' AND OLD.status <> 'CLOSED' THEN
        SELECT status, listing_type INTO v_status, v_listing FROM property WHERE property_id = NEW.property_id FOR UPDATE;
        IF v_status <> 'AVAILABLE' OR v_listing <> 'FOR_SALE' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sale closing requires an available FOR_SALE property';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_sale_status_sync
AFTER UPDATE ON sale_transaction
FOR EACH ROW
BEGIN
    IF NEW.status = 'CLOSED' AND OLD.status <> 'CLOSED' THEN
        UPDATE property SET status = 'SOLD' WHERE property_id = NEW.property_id;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_generate_monthly_invoices;
DELIMITER $$
CREATE PROCEDURE sp_generate_monthly_invoices(IN p_any_date DATE)
BEGIN
    DECLARE v_period_start DATE;
    DECLARE v_period_end DATE;
    SET v_period_start = DATE_SUB(p_any_date, INTERVAL DAYOFMONTH(p_any_date)-1 DAY);
    SET v_period_end = LAST_DAY(v_period_start);
    INSERT IGNORE INTO rental_invoice(lease_id,billing_period_start,billing_period_end,issue_date,due_date,amount_due,status)
    SELECT l.lease_id,v_period_start,v_period_end,CURRENT_DATE,
           DATE_ADD(v_period_start,INTERVAL l.payment_day-1 DAY),l.monthly_rent,'UNPAID'
    FROM lease l
    WHERE l.status='ACTIVE' AND l.start_date<=v_period_start AND l.end_date>=v_period_end;
END$$
DELIMITER ;

CREATE VIEW v_property_dashboard AS
SELECT p.property_id, p.title, p.property_type, p.listing_type, p.asking_price, p.status,
       CONCAT(op.full_name) AS owner_name, CONCAT(ap.full_name) AS agent_name,
       (SELECT COUNT(*) FROM lease l WHERE l.property_id=p.property_id AND l.status='ACTIVE') AS active_lease_count
FROM property p
JOIN owner o ON o.person_id=p.owner_id JOIN person op ON op.person_id=o.person_id
JOIN agent a ON a.person_id=p.agent_id JOIN person ap ON ap.person_id=a.person_id;

CREATE VIEW v_overdue_invoices AS
SELECT i.invoice_id, i.lease_id, t.person_id AS tenant_id, tp.full_name AS tenant_name,
       i.due_date, i.amount_due,
       COALESCE((SELECT SUM(pay.amount) FROM payment pay WHERE pay.invoice_id=i.invoice_id AND pay.status='POSTED' AND pay.payment_type<>'REFUND'),0) AS amount_received,
       i.amount_due - COALESCE((SELECT SUM(pay.amount) FROM payment pay WHERE pay.invoice_id=i.invoice_id AND pay.status='POSTED' AND pay.payment_type<>'REFUND'),0) AS balance_due
FROM rental_invoice i JOIN lease l ON l.lease_id=i.lease_id
JOIN tenant t ON t.person_id=l.tenant_id JOIN person tp ON tp.person_id=t.person_id
WHERE i.status IN ('UNPAID','PARTIALLY_PAID') AND i.due_date < CURRENT_DATE;
