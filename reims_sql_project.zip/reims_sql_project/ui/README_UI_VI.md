# Chạy giao diện web REIMS

Giao diện Flask kết nối đến MySQL Server. Hãy chạy `01_schema.sql` và `02_seed_1000_plus.sql` trong MySQL Workbench trước khi mở web.

## Khởi động nhanh

- Linux/macOS: chạy `run_ui.sh` trong thư mục `ui`.
- Windows: nhấp đúp `run_ui.bat`.

Launcher tự tạo môi trường Python và cài thư viện khi cần. Mặc định, ứng dụng kết nối tới `127.0.0.1:3306`, database `reims_db`, user `root`, mật khẩu `1`. Có thể đặt các biến `REIMS_DB_HOST`, `REIMS_DB_PORT`, `REIMS_DB_USER`, `REIMS_DB_PASSWORD`, `REIMS_DB_NAME` trước khi chạy để dùng thông tin khác.

Mở <http://127.0.0.1:5000>. MySQL Server phải đang chạy.

## Chức năng hiện có

- Xem tổng quan tài sản, lease đang hoạt động, tin đăng bán và tiền thu trong tháng.
- Tìm kiếm/lọc và thêm bất động sản nhà ở hoặc thương mại.
- Tạo lease, kích hoạt hoặc kết thúc lease.
- Ghi payment theo lease và xem lịch sử thu/hoàn tiền.
- Tạo yêu cầu bảo trì và cập nhật tiến độ.

Ứng dụng demo chưa có đăng nhập hoặc phân quyền tài khoản web.
