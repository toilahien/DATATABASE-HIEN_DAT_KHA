# Chạy giao diện web REIMS

Đây là giao diện demo Flask kết nối MySQL. MySQL Workbench dùng để chạy script và xem/quản trị cơ sở dữ liệu; Flask là giao diện web mà người dùng thao tác hằng ngày.

## 1. Cài và khởi động MySQL Server

Cài **MySQL Server 8.0.16+** và MySQL Workbench. Workbench là công cụ quản trị; chỉ cài Workbench thì chưa có server để lưu dữ liệu. Mở Workbench, kết nối đến MySQL Server local, rồi chạy các file theo thứ tự:

1. `01_schema.sql`
2. `02_seed_1000_plus.sql`

Database cần có dữ liệu demo vì các form tenant, owner, agent và property lấy danh sách từ database.

## 2. Cài môi trường Python

Cần Python 3.10 trở lên. Mở terminal tại thư mục `ui`.

### Windows PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:REIMS_DB_HOST="127.0.0.1"
$env:REIMS_DB_PORT="3306"
$env:REIMS_DB_USER="root"
$env:REIMS_DB_PASSWORD="mat_khau_mysql_cua_ban"
$env:REIMS_DB_NAME="reims_db"
python app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export REIMS_DB_HOST=127.0.0.1
export REIMS_DB_PORT=3306
export REIMS_DB_USER=root
export REIMS_DB_PASSWORD='mat_khau_mysql_cua_ban'
export REIMS_DB_NAME=reims_db
python app.py
```

Thay `mat_khau_mysql_cua_ban` bằng mật khẩu bạn đặt cho MySQL. Nếu bạn có user MySQL riêng, dùng user đó thay `root`.

## 3. Mở giao diện

Khi terminal báo Flask đang chạy, mở trình duyệt tại <http://127.0.0.1:5000>.

Giao diện hiện có:

- Tổng quan số tài sản theo trạng thái, lease active, hóa đơn quá hạn và tiền thu trong tháng.
- Tìm tài sản theo tên/địa chỉ, lọc trạng thái, tạo property nhà ở hoặc thương mại.
- Tạo lease PENDING, duyệt để kích hoạt, kết thúc lease; trigger trong MySQL đồng bộ trạng thái property.
- Ghi thanh toán theo invoice, tính số dư và cập nhật trạng thái hóa đơn.
- Tạo yêu cầu bảo trì và cập nhật tiến độ; trigger đồng bộ trạng thái property.

## Lỗi kết nối phổ biến

- `Can't connect to MySQL server`: kiểm tra MySQL Server đang chạy và cổng kết nối đúng.
- `Access denied`: kiểm tra tên user/mật khẩu và quyền truy cập database.
- `Unknown database 'reims_db'`: chạy `01_schema.sql` trước.
- Lỗi thiếu bảng/dữ liệu: chạy đầy đủ cả `01_schema.sql` rồi `02_seed_1000_plus.sql`.

Đây là ứng dụng demo chạy local cho đồ án. Chưa có đăng nhập/phân quyền người dùng, nên không đưa lên internet công khai như một sản phẩm production.
