"""Small Flask interface for the REIMS course project."""
import os
from contextlib import contextmanager
from datetime import date

import pymysql
from pymysql.cursors import DictCursor
from flask import Flask, flash, redirect, render_template, request, url_for
from werkzeug.exceptions import HTTPException

app = Flask(__name__)
app.secret_key = os.getenv("REIMS_FLASK_SECRET", "local-demo-change-this-secret")


def connect_db():
    return pymysql.connect(
        host=os.getenv("REIMS_DB_HOST", "127.0.0.1"),
        port=int(os.getenv("REIMS_DB_PORT", "3306")),
        user=os.getenv("REIMS_DB_USER", "root"),
        password=os.getenv("REIMS_DB_PASSWORD", ""),
        database=os.getenv("REIMS_DB_NAME", "reims_db"),
        charset="utf8mb4",
        cursorclass=DictCursor,
        autocommit=False,
    )


@contextmanager
def db_cursor():
    conn = connect_db()
    try:
        with conn.cursor() as cur:
            yield conn, cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def money(value):
    return f"{value:,.0f} VND" if value is not None else "—"


@app.template_filter("money")
def money_filter(value):
    return money(value)


@app.route("/")
def dashboard():
    with db_cursor() as (_, cur):
        cur.execute("SELECT status, COUNT(*) AS total FROM property GROUP BY status")
        statuses = {row["status"]: row["total"] for row in cur.fetchall()}
        cur.execute("SELECT COUNT(*) AS total FROM lease WHERE status='ACTIVE'")
        active_leases = cur.fetchone()["total"]
        cur.execute("SELECT COUNT(*) AS total FROM v_overdue_invoices WHERE balance_due > 0")
        overdue = cur.fetchone()["total"]
        cur.execute("""SELECT COALESCE(SUM(amount),0) AS total FROM payment
                       WHERE status='POSTED' AND payment_type <> 'REFUND'
                       AND payment_date >= DATE_FORMAT(CURRENT_DATE,'%Y-%m-01')""")
        cash_this_month = cur.fetchone()["total"]
        cur.execute("""SELECT property_id,title,status,asking_price,listing_type
                       FROM property ORDER BY created_at DESC,property_id DESC LIMIT 8""")
        recent_properties = cur.fetchall()
    return render_template("dashboard.html", statuses=statuses, active_leases=active_leases,
                           overdue=overdue, cash_this_month=cash_this_month,
                           recent_properties=recent_properties)


@app.route("/properties")
def properties():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    sql = """SELECT property_id,title,address,property_type,listing_type,asking_price,status,
                    owner_name,agent_name
             FROM v_property_dashboard WHERE 1=1"""
    params = []
    if q:
        sql += " AND (title LIKE %s OR address LIKE %s)"
        params.extend([f"%{q}%", f"%{q}%"])
    if status:
        sql += " AND status=%s"
        params.append(status)
    sql += " ORDER BY property_id DESC LIMIT 500"
    with db_cursor() as (_, cur):
        cur.execute(sql, params)
        rows = cur.fetchall()
    return render_template("properties.html", properties=rows, q=q, selected_status=status)


@app.route("/properties/new", methods=["GET", "POST"])
def new_property():
    if request.method == "POST":
        try:
            title = request.form["title"].strip()
            address = request.form["address"].strip()
            property_type = request.form["property_type"]
            listing_type = request.form["listing_type"]
            asking_price = float(request.form["asking_price"])
            owner_id = int(request.form["owner_id"])
            agent_id = int(request.form["agent_id"])
            if not title or not address or asking_price <= 0:
                raise ValueError("Nhập tên, địa chỉ và giá chào hợp lệ.")
            with db_cursor() as (conn, cur):
                cur.execute("""INSERT INTO property(title,address,property_type,listing_type,asking_price,status,owner_id,agent_id)
                               VALUES(%s,%s,%s,%s,%s,'AVAILABLE',%s,%s)""",
                            (title,address,property_type,listing_type,asking_price,owner_id,agent_id))
                new_id = cur.lastrowid
                if property_type == "RESIDENTIAL":
                    bedrooms = int(request.form["bedrooms"])
                    bathrooms = int(request.form["bathrooms"])
                    area = float(request.form["area_sqm"])
                    furnished = request.form.get("furnished_status") or None
                    if bedrooms < 0 or bathrooms < 0 or area <= 0:
                        raise ValueError("Diện tích phải dương; số phòng không được âm.")
                    cur.execute("""INSERT INTO residential_property(property_id,bedrooms,bathrooms,area_sqm,furnished_status)
                                   VALUES(%s,%s,%s,%s,%s)""", (new_id,bedrooms,bathrooms,area,furnished))
                elif property_type == "COMMERCIAL":
                    floor_area = float(request.form["floor_area_sqm"])
                    parking_spaces = int(request.form.get("parking_spaces") or 0)
                    if floor_area <= 0 or parking_spaces < 0:
                        raise ValueError("Diện tích phải dương; số chỗ đỗ xe không được âm.")
                    cur.execute("""INSERT INTO commercial_property(property_id,business_type,floor_area_sqm,parking_spaces)
                                   VALUES(%s,%s,%s,%s)""",
                                (new_id,request.form.get("business_type") or None,floor_area,parking_spaces))
                else:
                    raise ValueError("Loại bất động sản không hợp lệ.")
            flash(f"Đã tạo bất động sản #{new_id}.", "success")
            return redirect(url_for("properties"))
        except (ValueError, KeyError, TypeError) as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(f"Không lưu được bất động sản: {exc}", "error")
    with db_cursor() as (_, cur):
        cur.execute("SELECT o.person_id,p.full_name FROM owner o JOIN person p USING(person_id) ORDER BY p.full_name LIMIT 500")
        owners = cur.fetchall()
        cur.execute("SELECT a.person_id,p.full_name FROM agent a JOIN person p USING(person_id) ORDER BY p.full_name LIMIT 500")
        agents = cur.fetchall()
    return render_template("property_new.html", owners=owners, agents=agents)


@app.route("/leases", methods=["GET", "POST"])
def leases():
    if request.method == "POST":
        try:
            property_id = int(request.form["property_id"])
            tenant_id = int(request.form["tenant_id"])
            start_date = date.fromisoformat(request.form["start_date"])
            end_date = date.fromisoformat(request.form["end_date"])
            rent = float(request.form["monthly_rent"])
            deposit = float(request.form.get("deposit_amount") or 0)
            payment_day = int(request.form.get("payment_day") or 1)
            with db_cursor() as (_, cur):
                cur.execute("SELECT status,listing_type,agent_id FROM property WHERE property_id=%s FOR UPDATE", (property_id,))
                prop = cur.fetchone()
                if not prop or prop["status"] != "AVAILABLE" or prop["listing_type"] != "FOR_RENT":
                    raise ValueError("Chỉ tạo hợp đồng cho bất động sản đang AVAILABLE và FOR_RENT.")
                cur.execute("SELECT person_id FROM tenant WHERE person_id=%s", (tenant_id,))
                if not cur.fetchone():
                    raise ValueError("Không tìm thấy tenant_id trong bảng TENANT.")
                if end_date <= start_date or rent <= 0 or deposit < 0 or not 1 <= payment_day <= 28:
                    raise ValueError("Kiểm tra ngày thuê, tiền thuê, tiền cọc và ngày thanh toán.")
                cur.execute("""INSERT INTO lease(start_date,end_date,monthly_rent,deposit_amount,payment_day,
                              status,property_id,tenant_id,agent_id)
                              VALUES(%s,%s,%s,%s,%s,'PENDING',%s,%s,%s)""",
                            (start_date, end_date, rent, deposit, payment_day, property_id, tenant_id, prop["agent_id"]))
            flash("Đã tạo hợp đồng PENDING. Quản lý có thể kích hoạt sau khi duyệt.", "success")
        except (ValueError, KeyError, TypeError) as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(f"Không lưu được hợp đồng: {exc}", "error")
        return redirect(url_for("leases"))

    with db_cursor() as (_, cur):
        cur.execute("""SELECT l.lease_id,l.start_date,l.end_date,l.monthly_rent,l.status,l.property_id,
                              p.title, l.tenant_id,tp.full_name AS tenant_name,l.agent_id
                       FROM lease l JOIN property p ON p.property_id=l.property_id
                       JOIN tenant t ON t.person_id=l.tenant_id JOIN person tp ON tp.person_id=t.person_id
                       ORDER BY l.lease_id DESC LIMIT 300""")
        rows = cur.fetchall()
        cur.execute("""SELECT property_id,title FROM property
                       WHERE status='AVAILABLE' AND listing_type='FOR_RENT' ORDER BY title""")
        available_properties = cur.fetchall()
        cur.execute("SELECT person_id,full_name FROM tenant t JOIN person p USING(person_id) ORDER BY full_name LIMIT 500")
        tenants = cur.fetchall()
    return render_template("leases.html", leases=rows, available_properties=available_properties, tenants=tenants)


@app.post("/leases/<int:lease_id>/status")
def update_lease_status(lease_id):
    new_status = request.form.get("status")
    if new_status not in {"ACTIVE", "EXPIRED", "TERMINATED", "REJECTED"}:
        flash("Trạng thái hợp đồng không hợp lệ.", "error")
        return redirect(url_for("leases"))
    try:
        with db_cursor() as (_, cur):
            cur.execute("UPDATE lease SET status=%s WHERE lease_id=%s", (new_status, lease_id))
        flash("Đã cập nhật trạng thái hợp đồng.", "success")
    except Exception as exc:
        flash(f"Cơ sở dữ liệu từ chối chuyển trạng thái: {exc}", "error")
    return redirect(url_for("leases"))


@app.route("/payments", methods=["GET", "POST"])
def payments():
    if request.method == "POST":
        try:
            invoice_id = int(request.form["invoice_id"])
            amount = float(request.form["amount"])
            pay_date = date.fromisoformat(request.form["payment_date"])
            method = request.form.get("payment_method") or None
            if amount <= 0:
                raise ValueError("Số tiền thanh toán phải lớn hơn 0.")
            with db_cursor() as (_, cur):
                cur.execute("SELECT * FROM rental_invoice WHERE invoice_id=%s FOR UPDATE", (invoice_id,))
                invoice = cur.fetchone()
                if not invoice or invoice["status"] == "VOID":
                    raise ValueError("Không tìm thấy hóa đơn hoặc hóa đơn đã bị hủy.")
                cur.execute("""SELECT COALESCE(SUM(amount),0) AS received FROM payment
                               WHERE invoice_id=%s AND status='POSTED' AND payment_type<>'REFUND'""", (invoice_id,))
                received = float(cur.fetchone()["received"])
                if received + amount > float(invoice["amount_due"]):
                    raise ValueError("Số tiền nhận vượt quá số dư hóa đơn.")
                cur.execute("""INSERT INTO payment(lease_id,invoice_id,payment_date,amount,payment_type,payment_method)
                               VALUES(%s,%s,%s,%s,'RENT',%s)""",
                            (invoice["lease_id"], invoice_id, pay_date, amount, method))
                new_status = "PAID" if received + amount == float(invoice["amount_due"]) else "PARTIALLY_PAID"
                cur.execute("UPDATE rental_invoice SET status=%s WHERE invoice_id=%s", (new_status, invoice_id))
            flash("Đã ghi nhận thanh toán.", "success")
        except (ValueError, KeyError, TypeError) as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(f"Không ghi được thanh toán: {exc}", "error")
        return redirect(url_for("payments"))

    with db_cursor() as (_, cur):
        cur.execute("""SELECT i.invoice_id,i.lease_id,i.due_date,i.amount_due,i.status,p.property_id,p.title,
                              COALESCE((SELECT SUM(pay.amount) FROM payment pay WHERE pay.invoice_id=i.invoice_id
                                        AND pay.status='POSTED' AND pay.payment_type<>'REFUND'),0) AS received
                       FROM rental_invoice i JOIN lease l ON l.lease_id=i.lease_id
                       JOIN property p ON p.property_id=l.property_id
                       WHERE i.status IN ('UNPAID','PARTIALLY_PAID') ORDER BY i.due_date LIMIT 300""")
        invoices = cur.fetchall()
        cur.execute("""SELECT pay.payment_id,pay.payment_date,pay.amount,pay.payment_type,pay.payment_method,
                              pay.status,pay.lease_id,pay.invoice_id,p.title
                       FROM payment pay JOIN lease l ON l.lease_id=pay.lease_id
                       JOIN property p ON p.property_id=l.property_id
                       ORDER BY pay.payment_date DESC,pay.payment_id DESC LIMIT 100""")
        recent_payments = cur.fetchall()
    return render_template("payments.html", invoices=invoices, recent_payments=recent_payments, today=date.today().isoformat())


@app.route("/maintenance", methods=["GET", "POST"])
def maintenance():
    if request.method == "POST":
        try:
            lease_id = int(request.form["lease_id"])
            description = request.form["description"].strip()
            estimated = float(request.form["estimated_cost"]) if request.form.get("estimated_cost") else None
            if not description or (estimated is not None and estimated < 0):
                raise ValueError("Nhập mô tả và chi phí dự kiến hợp lệ.")
            with db_cursor() as (_, cur):
                cur.execute("SELECT lease_id FROM lease WHERE lease_id=%s AND status='ACTIVE'", (lease_id,))
                if not cur.fetchone():
                    raise ValueError("Yêu cầu bảo trì phải thuộc hợp đồng ACTIVE.")
                cur.execute("""INSERT INTO maintenance_request(lease_id,description,report_date,estimated_cost)
                               VALUES(%s,%s,CURRENT_DATE,%s)""", (lease_id, description, estimated))
            flash("Đã tạo yêu cầu bảo trì.", "success")
        except (ValueError, KeyError, TypeError) as exc:
            flash(str(exc), "error")
        except Exception as exc:
            flash(f"Không tạo được yêu cầu: {exc}", "error")
        return redirect(url_for("maintenance"))

    with db_cursor() as (_, cur):
        cur.execute("""SELECT m.request_id,m.description,m.report_date,m.estimated_cost,m.actual_cost,m.status,
                              l.lease_id,p.property_id,p.title,tp.full_name AS tenant_name
                       FROM maintenance_request m JOIN lease l ON l.lease_id=m.lease_id
                       JOIN property p ON p.property_id=l.property_id
                       JOIN tenant t ON t.person_id=l.tenant_id JOIN person tp ON tp.person_id=t.person_id
                       ORDER BY m.report_date DESC,m.request_id DESC LIMIT 300""")
        rows = cur.fetchall()
        cur.execute("""SELECT l.lease_id,p.title,tp.full_name AS tenant_name FROM lease l
                       JOIN property p ON p.property_id=l.property_id
                       JOIN tenant t ON t.person_id=l.tenant_id JOIN person tp ON tp.person_id=t.person_id
                       WHERE l.status='ACTIVE' ORDER BY l.lease_id DESC LIMIT 300""")
        active_leases = cur.fetchall()
    return render_template("maintenance.html", requests=rows, active_leases=active_leases)


@app.post("/maintenance/<int:request_id>/status")
def update_maintenance_status(request_id):
    new_status = request.form.get("status")
    if new_status not in {"PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED"}:
        flash("Trạng thái bảo trì không hợp lệ.", "error")
        return redirect(url_for("maintenance"))
    try:
        with db_cursor() as (_, cur):
            cur.execute("UPDATE maintenance_request SET status=%s, resolved_at=IF(%s='COMPLETED',NOW(),NULL) WHERE request_id=%s",
                        (new_status, new_status, request_id))
        flash("Đã cập nhật yêu cầu bảo trì.", "success")
    except Exception as exc:
        flash(f"Không cập nhật được yêu cầu: {exc}", "error")
    return redirect(url_for("maintenance"))


@app.errorhandler(Exception)
def handle_error(error):
    if isinstance(error, HTTPException):
        return render_template("error.html", error=error.description), error.code
    app.logger.exception("Request failed")
    return render_template("error.html", error=str(error)), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
