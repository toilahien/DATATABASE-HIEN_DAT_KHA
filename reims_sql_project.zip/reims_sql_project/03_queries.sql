USE reims_db;

-- Q1. Search available rental listings by budget and type.
SELECT d.property_id,d.title,p.address,d.property_type,d.asking_price
FROM v_property_dashboard d
JOIN property p ON p.property_id=d.property_id
WHERE d.status='AVAILABLE' AND d.listing_type='FOR_RENT' AND d.asking_price BETWEEN 8000000 AND 20000000
ORDER BY d.asking_price;

-- Q2. Current inventory and occupancy by property class.
SELECT property_type,
       COUNT(*) AS total_properties,
       SUM(status='LEASED') AS leased,
       SUM(status='AVAILABLE') AS available,
       SUM(status='UNDER_MAINTENANCE') AS under_maintenance,
       SUM(status='SOLD') AS sold,
       ROUND(100*SUM(status='LEASED')/NULLIF(COUNT(*),0),2) AS leased_percent
FROM property GROUP BY property_type;

-- Q3. Owner portfolio and total posted rental income, including historical leases.
SELECT o.person_id,op.full_name,COUNT(DISTINCT p.property_id) AS property_count,
       COALESCE(SUM(pay.amount),0) AS posted_rental_cash
FROM owner o JOIN person op ON op.person_id=o.person_id
LEFT JOIN property p ON p.owner_id=o.person_id
LEFT JOIN lease l ON l.property_id=p.property_id
LEFT JOIN payment pay ON pay.lease_id=l.lease_id AND pay.status='POSTED' AND pay.payment_type='RENT'
GROUP BY o.person_id,op.full_name
ORDER BY posted_rental_cash DESC;

-- Q4. Overdue invoices (view); balance is calculated against actual posted receipts.
SELECT * FROM v_overdue_invoices ORDER BY balance_due DESC,due_date;

-- Q5. Agent activity, with separate aggregates so joins do not multiply counts or money.
SELECT a.person_id,pe.full_name,a.commission_rate,
       COALESCE(lc.lease_count,0) AS lease_count,
       COALESCE(sc.closed_sales,0) AS closed_sales,
       COALESCE(sc.closed_sales_value,0) AS closed_sales_value
FROM agent a JOIN person pe ON pe.person_id=a.person_id
LEFT JOIN (SELECT agent_id,COUNT(*) AS lease_count FROM lease GROUP BY agent_id) lc ON lc.agent_id=a.person_id
LEFT JOIN (SELECT agent_id,COUNT(*) AS closed_sales,SUM(sale_price) AS closed_sales_value
           FROM sale_transaction WHERE status='CLOSED' GROUP BY agent_id) sc ON sc.agent_id=a.person_id
ORDER BY closed_sales_value DESC,lease_count DESC;

-- Q6. Tenants who have never signed a lease (NOT EXISTS subquery).
SELECT t.person_id,p.full_name
FROM tenant t JOIN person p ON p.person_id=t.person_id
WHERE NOT EXISTS (SELECT 1 FROM lease l WHERE l.tenant_id=t.person_id)
ORDER BY p.full_name;

-- Q7. Properties with open maintenance work and their current lease/tenant, if any.
SELECT p.property_id,p.title,p.status,m.request_id,m.description,m.status AS repair_status,
       l.lease_id,tp.full_name AS tenant_name
FROM property p
JOIN lease l ON l.property_id=p.property_id AND l.status='ACTIVE'
JOIN maintenance_request m ON m.lease_id=l.lease_id AND m.status IN ('PENDING','IN_PROGRESS')
JOIN tenant t ON t.person_id=l.tenant_id JOIN person tp ON tp.person_id=t.person_id
ORDER BY m.report_date;

-- Q8. Leases with more than one unpaid invoice and total balance.
SELECT l.lease_id,l.property_id,l.tenant_id,COUNT(*) AS unpaid_invoice_count,
       SUM(i.amount_due-COALESCE(x.received,0)) AS balance_due
FROM lease l JOIN rental_invoice i ON i.lease_id=l.lease_id
LEFT JOIN (SELECT invoice_id,SUM(amount) AS received FROM payment
           WHERE status='POSTED' AND payment_type<>'REFUND' GROUP BY invoice_id) x
       ON x.invoice_id=i.invoice_id
WHERE i.status IN ('UNPAID','PARTIALLY_PAID')
GROUP BY l.lease_id,l.property_id,l.tenant_id
HAVING COUNT(*)>1
ORDER BY balance_due DESC;

-- Q9. Monthly rental cash flow for the last 12 months.
SELECT DATE_FORMAT(payment_date,'%Y-%m') AS month,
       SUM(CASE WHEN payment_type='REFUND' THEN -amount ELSE amount END) AS net_cash_received,
       COUNT(*) AS payment_count
FROM payment
WHERE status='POSTED' AND payment_date >= DATE_SUB(CURRENT_DATE,INTERVAL 12 MONTH)
GROUP BY DATE_FORMAT(payment_date,'%Y-%m')
ORDER BY month;

-- Q10. Properties whose area is above the average for their own subtype.
WITH all_areas AS (
    SELECT p.property_id,p.title,p.property_type,r.area_sqm AS area
    FROM property p JOIN residential_property r ON r.property_id=p.property_id
    UNION ALL
    SELECT p.property_id,p.title,p.property_type,c.floor_area_sqm AS area
    FROM property p JOIN commercial_property c ON c.property_id=p.property_id
), subtype_avg AS (
    SELECT property_type,AVG(area) AS avg_area FROM all_areas GROUP BY property_type
)
SELECT x.property_id,x.title,x.property_type,x.area,a.avg_area
FROM all_areas x JOIN subtype_avg a USING(property_type)
WHERE x.area>a.avg_area ORDER BY x.property_type,x.area DESC;

-- Q11. Active leases ending within 60 days, including tenant/agent contacts.
SELECT l.lease_id,l.end_date,l.monthly_rent,
       tp.full_name AS tenant_name,tp.phone AS tenant_phone,
       ap.full_name AS agent_name,ap.phone AS agent_phone
FROM lease l JOIN tenant t ON t.person_id=l.tenant_id JOIN person tp ON tp.person_id=t.person_id
JOIN agent a ON a.person_id=l.agent_id JOIN person ap ON ap.person_id=a.person_id
WHERE l.status='ACTIVE' AND l.end_date BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE,INTERVAL 60 DAY)
ORDER BY l.end_date;

-- Q12. Properties whose cumulative posted rent receipts exceed the average property revenue.
WITH property_revenue AS (
    SELECT p.property_id,p.title,COALESCE(SUM(pay.amount),0) AS rent_received
    FROM property p LEFT JOIN lease l ON l.property_id=p.property_id
    LEFT JOIN payment pay ON pay.lease_id=l.lease_id AND pay.status='POSTED' AND pay.payment_type='RENT'
    GROUP BY p.property_id,p.title
)
SELECT property_id,title,rent_received
FROM property_revenue
WHERE rent_received > (SELECT AVG(rent_received) FROM property_revenue)
ORDER BY rent_received DESC;

-- Q13. Revenue by agent and calendar quarter (aggregation + date functions).
SELECT l.agent_id,pe.full_name,YEAR(pay.payment_date) AS revenue_year,
       QUARTER(pay.payment_date) AS revenue_quarter,SUM(pay.amount) AS rent_received
FROM payment pay JOIN lease l ON l.lease_id=pay.lease_id
JOIN agent a ON a.person_id=l.agent_id JOIN person pe ON pe.person_id=a.person_id
WHERE pay.status='POSTED' AND pay.payment_type='RENT'
GROUP BY l.agent_id,pe.full_name,YEAR(pay.payment_date),QUARTER(pay.payment_date)
ORDER BY revenue_year DESC,revenue_quarter DESC,rent_received DESC;

-- Q14. Compare completed sale value and estimated commission by agent.
SELECT a.person_id,pe.full_name,COUNT(s.sale_id) AS completed_sales,
       SUM(s.sale_price) AS sales_value,
       SUM(s.sale_price*s.commission_rate_at_sale/100) AS estimated_commission
FROM agent a JOIN person pe ON pe.person_id=a.person_id
LEFT JOIN sale_transaction s ON s.agent_id=a.person_id AND s.status='CLOSED'
GROUP BY a.person_id,pe.full_name
ORDER BY estimated_commission DESC;
